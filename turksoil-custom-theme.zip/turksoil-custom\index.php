<?php
$page = file_get_contents(__DIR__ . '/index.html');
if ($page === false) {
    wp_die('Unable to load the TURKSOIL website.');
}

$access = [
    'isAdmin' => current_user_can('manage_options'),
    'isLoggedIn' => is_user_logged_in(),
    'loginUrl' => wp_login_url(home_url('/')),
    'logoutUrl' => wp_logout_url(home_url('/')),
];
$access_script = '<script>window.TURKSOIL_WORDPRESS_ACCESS = ' .
    wp_json_encode($access, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) .
    ';</script>';

echo str_replace('</head>', $access_script . '</head>', $page);
